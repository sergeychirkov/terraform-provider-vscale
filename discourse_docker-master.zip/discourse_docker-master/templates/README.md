[pups](https://github.com/samsaffron/pups)-managed templates you may use to bootstrap your environment.
